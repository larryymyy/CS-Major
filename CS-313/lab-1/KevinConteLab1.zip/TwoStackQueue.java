/*
   Kevin Conte
   951620146

   19 October 2018
   =====================================
   Lab 1
 */


// This is the idea behind the HW1 written assignment.
// I essentially just translated my psuedocode into java to implement the queue with two stacks
public class TwoStackQueue<E> {

	private Stack<E> inbox, outbox;

	public TwoStackQueue() {

		// Create two empty stacks
		this.inbox = new Stack<E>();
		this.outbox = new Stack<E>();
	}

	public void enqueue(E newData) {
		// add the new element to the inbox
		this.inbox.push(newData);
	}

	public Node<E> dequeue() {

		// If the stack is empty, return null
		if(this.inbox.isEmpty() && this.outbox.isEmpty()) {
			return null;
		}

		// Take all elements out of the inbox and put them in the outbox (flip the stack);
		while(this.outbox.isEmpty()) {
			while(!this.inbox.isEmpty()) {
				this.outbox.push(this.inbox.pop().getData());
			}
		}

		// Return the top of the outbox stack
		return this.outbox.pop();
	}

	public boolean isEmpty() {

		// If the inbox and the outbox are both empty, so too must be the queue
		return this.inbox.isEmpty() && this.outbox.isEmpty();
	}

	public void printQueue() {

		// If the queue is empty, nothing can be printed to the screen
		if(this.inbox.isEmpty() && this.outbox.isEmpty()) {
			System.out.println("Queue is empty!");
		}


		// Flip the inbox stack
		while(this.outbox.isEmpty()) {
			while(!this.inbox.isEmpty()) {
				this.outbox.push(this.inbox.pop().getData());
			}
		}

		// Print the queue
		while(!this.outbox.isEmpty()) {
			E data = this.outbox.pop().getData();
			System.out.print(data + " ");
			this.inbox.push(data);
		}
		System.out.println();
	}

}
