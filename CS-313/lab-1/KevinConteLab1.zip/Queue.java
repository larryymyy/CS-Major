/*
   Kevin Conte
   951620146

   19 October 2018
   =====================================
   Lab 1
 */


public class Queue<E> {
	private Node<E> head;
	private Node<E> tail;
	
	public Queue(){
		// We want to initialize our Queue to be empty
		// (ie) set head and tail to be null

		// Setting the head and tail both to be null
		this.head = this.tail = null;
	}
	
	public void enqueue(E newData){
		// Create a new node whose data is newData and whose next node is null
		// Update head and tail
		// Hint: Think about what's different for the first node added to the Queue

		// Create a new node for the data to be enqueued
		Node<E> newNode = new Node<E>(newData, null);

		// If the tail is null (i.e. first element to be added), head and tail both are the new data node
		if(this.tail == null) {
			this.head = this.tail = newNode;
			return;
		}

		// Otherwise, add the new node to the end and update the tail.
		this.tail.setNext(newNode);
		this.tail = newNode;
	}
	
	public Node<E> dequeue(){
		// Return the head of the Queue
		// Update head
		// Hint: The order you implement the above 2 tasks matters, so use a temporary node
	 	//	     to hold important information
		// Hint: Return null on a empty Queue

		// If the head is null, the queue is empty
		if(this.head == null)
			return null;
		
		// Otherwise, create a temporary node that is a clone of the head
		Node<E> headNode = this.head;

		// Update the head to be the next node
		this.head = this.head.getNext();

		// If the head is now null, so should be the tail
		if(this.head == null)
			this.tail = null;

		// return the temporary node
		return headNode;
	}
	
	public boolean isEmpty(){
		// Check if the Queue is empty

		// If head and tail both empty, queue is empty
		return this.head == null && this.tail == null;
	}
	
	public void printQueue(){
		// Loop through your queue and print each Node's data


		// If the queue is empty, nothing can be printed
		if(this.isEmpty()) {
			System.out.println("Queue is empty!");
			return;
		}

		// Iterate over each node and print its contents
		Node<E> current = this.head;
		while(current != null) {
			System.out.println(current.getData());
			current = current.getNext();
		}
	}
}
