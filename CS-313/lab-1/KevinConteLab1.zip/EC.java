/*
   Kevin Conte
   951620146

   19 October 2018
   =====================================
   Lab 1
 */


import java.util.Scanner;

public class EC {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in); // Allow input
		int numProblems = Integer.parseInt(scanner.nextLine()); // Get number of lines to parse
		for(int i = 0; i < numProblems; i++) { // Loop until all lines read
			String test = scanner.nextLine(); // Read next line into string
			// test if string is palindrome
			if(isPalindrome(test)) {
				System.out.println("This is a Palindrome.");
			} else {
				System.out.println("Not a Palindrome.");
			}
		}
		scanner.close();
		System.exit(0);
	}

	// IsPalindrome
	public static boolean isPalindrome(String s) {
		// Push all elements into TwoStackQueue and Stack
		TwoStackQueue<Character> queue = new TwoStackQueue<Character>();
		Stack<Character> stack = new Stack<Character>();
		for(char c : s.toCharArray()) {
			stack.push(c);
			queue.enqueue(c);
		}

		// Then compare each element as it is removed from the appropriate data structure
		// If the elements removed do not match, the string is not a palindrome
		while(!stack.isEmpty() && !queue.isEmpty()) {
			if(stack.pop().getData() != queue.dequeue().getData()) {
				return false;
			}
		}
		return true;
	}
}
